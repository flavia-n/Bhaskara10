﻿
namespace TesteConta
{
    internal class Bhaskara
    {
        private int v1;
        private int v2;
        private int v3;
        private double a;
        private double b;
        private double c;

        public Bhaskara(int v1, int v2, int v3)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
        }

        public Bhaskara(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        internal double CalcularDelta()
        {
            throw new NotImplementedException();
        }

        internal bool TemRaizesReais()
        {
            throw new NotImplementedException();
        }
    }
}